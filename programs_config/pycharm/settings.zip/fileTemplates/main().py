






def print_hi(name: str):
    print(f'Hi, {name}')



def main():
    print_hi('Python')


if __name__ == '__main__':
    main()
